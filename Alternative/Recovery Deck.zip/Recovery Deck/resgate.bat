@echo off
color 0B
echo ==================================================
echo       LINHA DE MONTAGEM E RESGATE - DECK DEVICES
echo ==================================================
echo.

echo Selecione o modelo que sera instalado nesta placa:
echo [1] Pulse Deck
echo [2] Core Deck
echo.
set /p OPCAO="Digite o numero (1 ou 2) e aperte Enter: "

set PASTA_MODELO=
if "%OPCAO%"=="1" set PASTA_MODELO=Pulse
if "%OPCAO%"=="2" set PASTA_MODELO=Core

if "%PASTA_MODELO%"=="" (
    echo.
    echo ERRO: Opcao invalida! Feche a janela e tente novamente.
    pause
    exit
)

echo.
echo -^> Modelo selecionado: %PASTA_MODELO% DECK
echo.

set /p PORTA_NUM="Digite APENAS O NUMERO da porta da placa (Ex: 4) e aperte Enter: "
set COMPORT=COM%PORTA_NUM%

echo.
echo [1/5] Forcando Modo Bootloader na porta %COMPORT% (Derrubando o sistema)...
mode %COMPORT%: BAUD=1200 >nul 2>&1
echo Aguardando o pendrive RPI-RP2 aparecer...
timeout /t 4 /nobreak >nul

:BUSCAR_RPI
set RPI_DRIVE=
for %%D in (D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    vol %%D: 2>nul | find "RPI-RP2" >nul
    if not errorlevel 1 set RPI_DRIVE=%%D:
)
if "%RPI_DRIVE%"=="" (
    timeout /t 2 /nobreak >nul
    goto BUSCAR_RPI
)
echo -^> Placa encontrada na unidade %RPI_DRIVE%

echo.
echo [2/5] Aplicando Flash Nuke (Limpando a memoria completa)...
copy "flash_nuke.uf2" %RPI_DRIVE%\ >nul
echo Aguardando a placa formatar e reiniciar...
timeout /t 8 /nobreak >nul

:BUSCAR_RPI2
set RPI_DRIVE=
for %%D in (D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    vol %%D: 2>nul | find "RPI-RP2" >nul
    if not errorlevel 1 set RPI_DRIVE=%%D:
)
if "%RPI_DRIVE%"=="" (
    timeout /t 2 /nobreak >nul
    goto BUSCAR_RPI2
)

echo.
echo [3/5] Instalando o CircuitPython limpo...
copy "circuitpython.uf2" %RPI_DRIVE%\ >nul
echo Aguardando a instalacao do sistema...
timeout /t 8 /nobreak >nul

:BUSCAR_CPY
set CPY_DRIVE=
for %%D in (D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    vol %%D: 2>nul | find "CIRCUITPY" >nul
    if not errorlevel 1 set CPY_DRIVE=%%D:
)
if "%CPY_DRIVE%"=="" (
    timeout /t 2 /nobreak >nul
    goto BUSCAR_CPY
)
echo -^> Pendrive CIRCUITPY montado na unidade %CPY_DRIVE%

echo.
echo [4/5] Injetando o firmware do modelo %PASTA_MODELO%...
xcopy "%PASTA_MODELO%\*" %CPY_DRIVE%\ /E /H /Y /C >nul

echo.
echo ==================================================
echo [5/5] SUCESSO ABSOLUTO!
echo A %PASTA_MODELO% Deck foi montada e esta pronta para uso!
echo ==================================================
pause