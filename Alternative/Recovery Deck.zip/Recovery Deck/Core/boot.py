import storage
import usb_cdc
import board
import digitalio
import supervisor

# Desativa o reinício automático para a conexão Serial não cair
supervisor.runtime.autoreload = False

# Jumper de Segurança no GP10 (conectar ao GND para ver a unidade no Windows)
jumper = digitalio.DigitalInOut(board.GP10)
jumper.direction = digitalio.Direction.INPUT
jumper.pull = digitalio.Pull.UP

# Se o jumper NÃO estiver conectado, a placa manda na memória (Setup pode sincronizar)
# Se o jumper ESTIVER no GND, o Windows manda na memória (Você pode editar o código)
if jumper.value:
    storage.remount("/", readonly=False) # Placa escreve nela mesma
    storage.disable_usb_drive()          
    usb_cdc.enable(console=False, data=True)
else:
    storage.remount("/", readonly=True)  # Windows escreve na placa
    usb_cdc.enable(console=True, data=True)
