import time
import board
import digitalio
import usb_hid
import usb_cdc
import json
import supervisor
import os

from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

# ==========================================
# IDENTIDADE DO FIRMWARE
# ==========================================

NOME_DA_DECK    = "Pulse"
VERSAO_FIRMWARE = "1.5"
IS_PULSE        = NOME_DA_DECK == "Pulse"

# ==========================================
# CONFIGURAÇÃO PADRÃO
# ==========================================

config_padrao = {
    "device_type": NOME_DA_DECK,
    "vib_enabled": True,
    "hapticShort": True,
    "hapticLong": True,
    "hapticIntensityPct": 50,
    "vib_duration": 0.05,
    "long_press_ms": 1500,
    "short_press_ms": 50,
    "perfis": [[{"tipo": "teclado", "curto": ["WINDOWS", "V"], "longo": None}] * 6]
}

try:
    with open("/config.json", "r") as f:
        config = json.load(f)
except:
    config = config_padrao

# ==========================================
# HARDWARE: MOTOR E BOTÕES
# ==========================================

if IS_PULSE:
    motor = digitalio.DigitalInOut(board.GP15)
    motor.direction = digitalio.Direction.OUTPUT
    motor.value = False

teclado = Keyboard(usb_hid.devices)
midia   = ConsumerControl(usb_hid.devices)

pinos = [board.GP28, board.GP27, board.GP26, board.GP4, board.GP5, board.GP6]
botoes = []
for p in pinos:
    btn = digitalio.DigitalInOut(p)
    btn.direction = digitalio.Direction.INPUT
    btn.pull = digitalio.Pull.DOWN if IS_PULSE else digitalio.Pull.UP
    botoes.append(btn)

def is_pressed(i):
    return botoes[i].value if IS_PULSE else not botoes[i].value

def acionar_motor(t=None, tipo="curto"):
    if not IS_PULSE:
        return
    master_vib    = config.get("vib_enabled", True)
    permite_curto = config.get("hapticShort", True)
    permite_longo = config.get("hapticLong", True)
    permitido = (tipo == "curto" and permite_curto) or (tipo == "longo" and permite_longo)
    if master_vib and permitido:
        pct            = config.get("hapticIntensityPct", 50)
        multiplicador = 1.0 + ((max(50, pct) - 50) / 50.0)
        duracao_base  = t if t else config.get("vib_duration", 0.05)
        motor.value = True
        time.sleep(duracao_base * multiplicador)
        motor.value = False

# ==========================================
# MAPEAMENTO DE KEYCODES
# ==========================================

KEYCODE_MAP = {
    "CONTROL": Keycode.CONTROL,
    "SHIFT":   Keycode.SHIFT,
    "ALT":     Keycode.ALT,
    "WINDOWS": Keycode.GUI,
    "WIN":     Keycode.GUI,
    "GUI":     Keycode.GUI,
    "ENTER":        Keycode.ENTER,
    "ESCAPE":       Keycode.ESCAPE,
    "BACKSPACE":    Keycode.BACKSPACE,
    "DELETE":       Keycode.DELETE,
    "TAB":          Keycode.TAB,
    "SPACE":        Keycode.SPACE,
    "PRINT_SCREEN": Keycode.PRINT_SCREEN,
    "OEM_2":        Keycode.FORWARD_SLASH,
    "NUMPAD0": Keycode.KEYPAD_ZERO,
    "NUMPAD1": Keycode.KEYPAD_ONE,
    "NUMPAD2": Keycode.KEYPAD_TWO,
    "NUMPAD3": Keycode.KEYPAD_THREE,
    "NUMPAD4": Keycode.KEYPAD_FOUR,
    "NUMPAD5": Keycode.KEYPAD_FIVE,
    "NUMPAD6": Keycode.KEYPAD_SIX,
    "NUMPAD7": Keycode.KEYPAD_SEVEN,
    "NUMPAD8": Keycode.KEYPAD_EIGHT,
    "NUMPAD9": Keycode.KEYPAD_NINE,
    "DECIMAL":  Keycode.KEYPAD_PERIOD,
    "ADD":      Keycode.KEYPAD_PLUS,
    "SUBTRACT": Keycode.KEYPAD_MINUS,
    "MULTIPLY": Keycode.KEYPAD_ASTERISK,
    "DIVIDE":   Keycode.KEYPAD_FORWARD_SLASH,
}

# ==========================================
# DISPARO DE ATALHOS
# ==========================================

def disparar_atalho(tipo, lista_teclas):
    if not lista_teclas:
        return

    if tipo == "executar":
        try:
            if usb_cdc.data and len(lista_teclas) > 0:
                caminho = lista_teclas[0]
                usb_cdc.data.write(f"CMD:RUN:{caminho}\r\n".encode('utf-8'))
                usb_cdc.data.flush()
        except:
            pass
        return

    if "APP_TOGGLE" in lista_teclas:
        try:
            if usb_cdc.data:
                usb_cdc.data.write(b"CMD:APP_TOGGLE\r\n")
                usb_cdc.data.flush()
        except:
            pass
        return

    is_media = tipo == "midia" or any("MEDIA" in t for t in lista_teclas)
    if is_media:
        for m in lista_teclas:
            m_upper = m.upper().replace("MEDIA_", "")
            if m_upper == "VOLUME_UP":    m_upper = "VOLUME_INCREMENT"
            elif m_upper == "VOLUME_DOWN": m_upper = "VOLUME_DECREMENT"
            elif m_upper == "NEXT":        m_upper = "SCAN_NEXT_TRACK"
            elif m_upper == "PREVIOUS":    m_upper = "SCAN_PREVIOUS_TRACK"
            try:
                midia.send(getattr(ConsumerControlCode, m_upper))
            except:
                pass
        return

    contem_oem2 = any(t.upper() == "OEM_2" for t in lista_teclas)
    codigos_seq = []
    for t in lista_teclas:
        t_upper = t.upper()
        if t_upper in KEYCODE_MAP:
            codigos_seq.append(KEYCODE_MAP[t_upper])
        else:
            try:
                codigos_seq.append(getattr(Keycode, t_upper))
            except:
                pass

    if codigos_seq:
        if contem_oem2:
            for kc in codigos_seq:
                teclado.send(kc)
                time.sleep(0.05)
        else:
            teclado.send(*codigos_seq)

# ==========================================
# ESTADO DOS BOTÕES
# ==========================================

estado_ant   = [False] * 6
tempo_press  = [0.0]   * 6
longo_exec   = [False] * 6
modo_sync    = False
perfil_atual = 0

# ==========================================
# LOOP PRINCIPAL
# ==========================================

while True:
    agora = time.monotonic()

    # --- Protocolo Serial ---
    if usb_cdc.data and usb_cdc.data.in_waiting > 0:
        try:
            linha = usb_cdc.data.readline().decode("utf-8").strip()
        except:
            linha = ""

        if "PING" in linha:
            try:
                usb_cdc.data.write(f"PONG:{NOME_DA_DECK}:{VERSAO_FIRMWARE}\r\n".encode())
                usb_cdc.data.flush()
            except:
                pass

        elif "SYNC_READ" in linha:
            try:
                with open("/config.json", "r") as f:
                    conteudo = f.read()
                conteudo = conteudo.replace("\n", "").replace("\r", "")
                usb_cdc.data.write(conteudo.encode("utf-8") + b"\r\n")
                usb_cdc.data.flush()
            except:
                try:
                    usb_cdc.data.write(b"ERROR\r\n")
                    usb_cdc.data.flush()
                except:
                    pass

        elif "CMD:UPDATE_FIRMWARE" in linha:
            try:
                supervisor.runtime.autoreload = False
                usb_cdc.data.write(b"UPDATE_READY\r\n")
                usb_cdc.data.flush()

                time.sleep(0.5)
                while usb_cdc.data.in_waiting > 0:
                    usb_cdc.data.read(usb_cdc.data.in_waiting)

                deadline = time.monotonic() + 120
                concluido = False

                with open("/temp_update.py", "wb") as f:
                    tail = b""
                    # Separamos a string em partes para que a palavra inteira 
                    # nunca exista no código fonte cru!
                    marcador_fim = b"###" + b"END_OTA" + b"###" 
                    
                    while time.monotonic() < deadline:
                        n = usb_cdc.data.in_waiting
                        if n > 0:
                            chunk = usb_cdc.data.read(n)
                            tail += chunk
                            
                            if marcador_fim in tail:
                                parte_valida = tail[:tail.index(marcador_fim)]
                                if parte_valida:
                                    f.write(parte_valida)
                                concluido = True
                                usb_cdc.data.write(b"ACK\r\n")
                                usb_cdc.data.flush()
                                break
                            
                            if len(tail) > 16:
                                f.write(tail[:-16])
                                tail = tail[-16:]
                            
                            usb_cdc.data.write(b"ACK\r\n")
                            usb_cdc.data.flush()

                if concluido:
                    try:
                        os.remove("/code.py")
                    except:
                        pass
                    os.rename("/temp_update.py", "/code.py")
                    usb_cdc.data.write(b"UPDATE_SUCCESS\r\n")
                    usb_cdc.data.flush()
                    time.sleep(1.0)
                else:
                    try:
                        os.remove("/temp_update.py")
                    except:
                        pass
                    usb_cdc.data.write(b"UPDATE_TIMEOUT\r\n")
                    usb_cdc.data.flush()

                supervisor.reload()

            except Exception as e:
                try:
                    usb_cdc.data.write(b"UPDATE_ERROR\r\n")
                    usb_cdc.data.flush()
                    time.sleep(0.5)
                    supervisor.reload()
                except:
                    pass

        elif "SYNC_START" in linha:
            modo_sync = True
            try:
                usb_cdc.data.write(b"READY\r\n")
                usb_cdc.data.flush()
            except:
                pass

            timeout_sync = time.monotonic() + 3
            while time.monotonic() < timeout_sync:
                if usb_cdc.data and usb_cdc.data.in_waiting > 0:
                    try:
                        novo_json = usb_cdc.data.readline().decode("utf-8").strip()
                        config = json.loads(novo_json)
                        with open("/config.json", "w") as f:
                            json.dump(config, f)
                        usb_cdc.data.write(b"SAVED\r\n")
                        usb_cdc.data.flush()
                    except:
                        try:
                            usb_cdc.data.write(b"ERROR\r\n")
                            usb_cdc.data.flush()
                        except:
                            pass
                    break
                time.sleep(0.005)

            acionar_motor(0.2)
            modo_sync = False

    # --- Lógica de Input ---
    if not modo_sync:
        for i in range(6):
            pres = is_pressed(i)

            if pres and not estado_ant[i]:
                tempo_press[i] = agora
                longo_exec[i]  = False
                acionar_motor(tipo="curto")

            elif pres and estado_ant[i]:
                if not longo_exec[i] and (agora - tempo_press[i]) >= (config.get("long_press_ms", 1500) / 1000.0):
                    longo_exec[i] = True
                    acionar_motor(0.15, tipo="longo")
                    try:
                        if usb_cdc.data:
                            usb_cdc.data.write(("CLICK:" + str(i) + ":LONG\r\n").encode())
                            usb_cdc.data.flush()
                        acao = config["perfis"][perfil_atual][i]
                        disparar_atalho(acao.get("tipo"), acao.get("longo"))
                    except:
                        pass

            elif not pres and estado_ant[i]:
                if not longo_exec[i] and (agora - tempo_press[i]) > (config.get("short_press_ms", 50) / 1000.0):
                    try:
                        if usb_cdc.data:
                            usb_cdc.data.write(("CLICK:" + str(i) + "\r\n").encode())
                            usb_cdc.data.flush()
                        acao = config["perfis"][perfil_atual][i]
                        disparar_atalho(acao.get("tipo"), acao.get("curto"))
                    except:
                        pass

            estado_ant[i] = pres

    time.sleep(0.005)